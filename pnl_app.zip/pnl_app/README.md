---
title: Etrm App
emoji: 🏆
colorFrom: red
colorTo: purple
sdk: docker
sdk_version: 5.34.1
app_file: app.py
pinned: false
license: mit
short_description: etrm prototype
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
