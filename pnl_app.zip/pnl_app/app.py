import sqlite3
import json
import click
import pandas as pd
import os
from flask import Flask, request, jsonify, render_template, g
from py_expression_eval import Parser
import dash
from dash import dcc, dash_table, html, Input, Output
import dash_bootstrap_components as dbc
import plotly.express as px

# --- INITIAL SETUP ---
DATABASE_FILE = 'etrm_database.db'
FORMULAS_FILE = 'formulas.json'

server = Flask(__name__)
server.config['DATABASE'] = DATABASE_FILE

# --- CALCULATION ENGINE ---
class PnlCalculationEngine:
    def __init__(self, formulas_path):
        with open(formulas_path, 'r') as f:
            self.formulas = json.load(f)['pnl_calculations']
        self.parser = Parser()
        self.parser.functions['SUM'] = lambda *args: sum(args)
        self.parser.functions['CASE'] = lambda condition, true_val, false_val: true_val if condition else false_val

    def calculate(self, input_data):
        context = {k: float(v) if str(v).replace('.', '', 1).replace('-', '', 1).isdigit() else v for k, v in input_data.items()}
        for formula_def in self.formulas:
            name = formula_def['name']
            expression = formula_def['expression']
            try:
                context['buy_sell'] = input_data.get('buy_sell', 'Buy')
                result = self.parser.evaluate(expression, context)
                context[name] = result
            except Exception as e:
                context[name] = 0
        return context

# --- DATABASE MANAGEMENT ---
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(server.config['DATABASE'], detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
    return g.db

@server.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    with server.open_resource('schema.sql', mode='r') as f:
        db.cursor().executescript(f.read())
    db.commit()

# --- COMMAND LINE INTERFACE (CLI) COMMANDS ---
@server.cli.command('init-db')
def init_db_command():
    init_db()
    click.echo('✅ Initialized the database.')

@server.cli.command('load-data')
def load_data_command():
    db = get_db()
    data_file = '06112025_ETRM Data.csv'
    if not os.path.exists(data_file):
        click.echo(f"❌ Error: Data file '{data_file}' not found.")
        return

    df = pd.read_csv(data_file)
    df.columns = [col.strip() for col in df.columns]
    if 'Physcal PnL' in df.columns:
        df = df.rename(columns={'Physcal PnL': 'Physical PnL'})

    # --- FINAL, ROBUST DATA CLEANING SECTION ---
    pnl_cols_to_convert = ['Physical PnL', 'Paper PnL', 'Net PnL']
    for col in pnl_cols_to_convert:
        if col in df.columns:
            # Clean the string: remove $, commas, and handle () for negatives
            cleaned_col = df[col].astype(str).str.replace('$', '', regex=False).str.replace(',', '', regex=False)
            cleaned_col = cleaned_col.str.replace('(', '-', regex=False).str.replace(')', '', regex=False).str.strip()
            # Now convert the cleaned string to a number
            df[col] = pd.to_numeric(cleaned_col, errors='coerce').fillna(0)
    # --- END OF FIX ---
    
    loaded_count = 0
    for index, row in df.iterrows():
        if pd.isna(row['Date']) or pd.isna(row['Cargo']):
            click.echo(f"⚠️ Warning: Skipping row {index+2} due to missing Date or Cargo.")
            continue
        
        trade_cursor = db.execute(
            'INSERT INTO trades (trade_date, product, trade_type, buy_sell, quantity, price, counterparty, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [row['Date'], row['Cargo'], 'Physical', 'Buy', 1, 0, 'Loaded from Excel', 'Closed']
        )
        trade_id = trade_cursor.lastrowid
        
        db.execute(
            'INSERT INTO pnl_report (trade_id, physical_pnl, paper_pnl, net_pnl, total_operating_costs) VALUES (?, ?, ?, ?, ?)',
            [trade_id, row['Physical PnL'], row.get('Paper PnL', 0), row['Net PnL'], 0]
        )
        loaded_count += 1

    db.commit()
    click.echo(f"✅ Successfully loaded {loaded_count} records from {data_file} into the database.")

# ... (The rest of the file is unchanged) ...
@server.cli.command('view-db')
def view_db_command():
    db = get_db()
    click.echo("--- Checking contents of pnl_report table ---")
    report_cursor = db.execute("SELECT * FROM pnl_report LIMIT 5")
    rows = report_cursor.fetchall()
    if not rows:
        click.echo("❌ The 'pnl_report' table is empty.")
    else:
        for row in rows:
            click.echo(dict(row))

@server.route('/')
def index():
    return render_template('index.html')

@server.route('/api/trades', methods=['GET', 'POST'])
def handle_trades():
    db = get_db()
    if request.method == 'POST':
        trade = request.json
        cursor = db.execute(
            """INSERT INTO trades (trade_date, product, trade_type, buy_sell, quantity, price, counterparty, status, 
                                  physical_premium, consultancy_fee, demurrage_cost, custom_charges, port_charges, 
                                  inspection_charges, tank_rental_cost, other_costs, hedging_pnl) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            [trade['trade_date'], trade['product'], trade['trade_type'], trade['buy_sell'], trade['quantity'],
             trade['price'], trade['counterparty'], 'Open', trade.get('physical_premium', 0), trade.get('consultancy_fee', 0),
             trade.get('demurrage_cost', 0), trade.get('custom_charges', 0), trade.get('port_charges', 0),
             trade.get('inspection_charges', 0), trade.get('tank_rental_cost', 0), trade.get('other_costs', 0), trade.get('hedging_pnl', 0)]
        )
        trade_id = cursor.lastrowid
        
        engine = PnlCalculationEngine(FORMULAS_FILE)
        pnl_results = engine.calculate(trade)
        db.execute(
            """INSERT INTO pnl_report (trade_id, physical_pnl, paper_pnl, total_operating_costs, net_pnl)
               VALUES (?, ?, ?, ?, ?)""",
            [trade_id, pnl_results.get('physical_pnl'), pnl_results.get('paper_pnl'), 
             pnl_results.get('total_operating_costs'), pnl_results.get('net_pnl')]
        )
        db.commit()
        return jsonify({"status": "success", "message": "Trade and P&L report created."})

    trades_cursor = db.execute('SELECT * FROM trades ORDER BY id DESC')
    trades = [dict(row) for row in trades_cursor.fetchall()]
    return jsonify(trades)
    
@server.route('/api/trades/<int:trade_id>/pnl', methods=['GET'])
def get_trade_pnl(trade_id):
    db = get_db()
    trade_cursor = db.execute("SELECT * FROM trades WHERE id = ?", [trade_id])
    trade_data = trade_cursor.fetchone()
    if not trade_data:
        return jsonify({"error": "Trade not found"}), 404
    engine = PnlCalculationEngine(FORMULAS_FILE)
    pnl_results = engine.calculate(dict(trade_data))
    return jsonify(pnl_results)

@server.route('/api/pnl_report', methods=['GET'])
def get_pnl_report():
    db = get_db()
    query = "SELECT t.id, t.trade_date, t.product, p.physical_pnl, p.paper_pnl, p.total_operating_costs, p.net_pnl FROM trades t JOIN pnl_report p ON t.id = p.trade_id ORDER BY t.id DESC"
    report_cursor = db.execute(query)
    report_data = [dict(row) for row in report_cursor.fetchall()]
    return jsonify(report_data)

@server.route('/api/marketdata', methods=['POST'])
def handle_market_data():
    db = get_db()
    data = request.json
    db.execute('REPLACE INTO market_data (price_date, product, price) VALUES (?, ?, ?)',[data['price_date'], data['product'], data['price']])
    db.commit()
    return jsonify({"status": "success", "message": "Market data saved."})

@server.route('/api/positions', methods=['GET'])
def get_positions():
    db = get_db()
    query = "SELECT product, SUM(CASE WHEN buy_sell = 'Buy' THEN quantity ELSE -quantity END) as net_position FROM trades WHERE status = 'Open' GROUP BY product"
    positions_cursor = db.execute(query)
    positions = [dict(row) for row in positions_cursor.fetchall()]
    return jsonify(positions)

@server.route('/api/run_valuation', methods=['POST'])
def run_valuation():
    db = get_db()
    valuation_date = request.json['valuation_date']
    open_trades_cursor = db.execute("SELECT * FROM trades WHERE status = 'Open'")
    open_trades = open_trades_cursor.fetchall()
    prices_cursor = db.execute("SELECT product, price FROM market_data WHERE price_date = ?", [valuation_date])
    market_prices = {row['product']: row['price'] for row in prices_cursor.fetchall()}
    if not market_prices:
        return jsonify({"error": f"No market data found for date {valuation_date}"}), 400
    valuation_results = []
    for trade in open_trades:
        product = trade['product']
        if product in market_prices:
            market_price = market_prices[product]
            trade_price = trade['price']
            quantity = trade['quantity']
            unrealized_pnl = (market_price - trade_price) * quantity
            if trade['buy_sell'] == 'Sell':
                unrealized_pnl *= -1
            db.execute('REPLACE INTO pnl_snapshots (snapshot_date, trade_id, unrealized_pnl) VALUES (?, ?, ?)',
                [valuation_date, trade['id'], unrealized_pnl]
            )
            valuation_results.append({"trade_id": trade['id'], "product": product, "unrealized_pnl": f"{unrealized_pnl:,.2f}"})
    db.commit()
    return jsonify(valuation_results)

dash_app = dash.Dash(__name__, server=server, url_base_pathname='/dashboard/', external_stylesheets=[dbc.themes.BOOTSTRAP])
dash_app.title = "P&L Dashboard"
dash_app.layout = dbc.Container([
    html.H1("P&L Report Dashboard", className="my-4"),
    dbc.Alert([html.A("Go back to Trade Entry", href="/", className="alert-link"), ". This dashboard shows calculated P&L for all trades."], color="info"),
    dbc.Row([
        dbc.Col(dcc.Graph(id='pnl-by-product-chart'), width=6),
        dbc.Col(dcc.Graph(id='pnl-timeseries-chart'), width=6),
    ], className="mb-4"),
    dash_table.DataTable(
        id='pnl-datatable',
        columns=[
            {"name": "Trade ID", "id": "id"}, {"name": "Date", "id": "trade_date"}, {"name": "Product", "id": "product"},
            {"name": "Physical P&L", "id": "physical_pnl", "type": "numeric", "format": {"specifier": ",.2f"}},
            {"name": "Paper P&L", "id": "paper_pnl", "type": "numeric", "format": {"specifier": ",.2f"}},
            {"name": "Op. Costs", "id": "total_operating_costs", "type": "numeric", "format": {"specifier": ",.2f"}},
            {"name": "Net P&L", "id": "net_pnl", "type": "numeric", "format": {"specifier": ",.2f"}},
        ],
        page_size=15, sort_action="native", filter_action="native",
        style_header={'backgroundColor': '#f8f9fa', 'fontWeight': 'bold'},
        style_data_conditional=[
            {'if': {'filter_query': '{net_pnl} > 0', 'column_id': 'net_pnl'}, 'color': 'green'},
            {'if': {'filter_query': '{net_pnl} < 0', 'column_id': 'net_pnl'}, 'color': 'red'}
        ]
    )
], fluid=True)

@dash_app.callback(
    Output('pnl-datatable', 'data'),
    Output('pnl-by-product-chart', 'figure'),
    Output('pnl-timeseries-chart', 'figure'),
    Input('pnl-datatable', 'page_current')
)
def update_dashboard_elements(_):
    with server.app_context():
        report_data = get_pnl_report().get_json()
        if not report_data:
            return [], {}, {}
        df = pd.DataFrame(report_data)
        
        pnl_columns = ['physical_pnl', 'paper_pnl', 'total_operating_costs', 'net_pnl']
        for col in pnl_columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)

        df['trade_date'] = pd.to_datetime(df['trade_date'], format='mixed', errors='coerce')
        df.dropna(subset=['trade_date'], inplace=True)
        df = df.sort_values(by='trade_date')

        pnl_by_product = df.groupby('product')['net_pnl'].sum().reset_index()
        df['cumulative_pnl'] = df.groupby('product')['net_pnl'].cumsum()

        bar_fig = px.bar(pnl_by_product, x='product', y='net_pnl', title='Total Net P&L by Product',
                         labels={'product': 'Product/Cargo', 'net_pnl': 'Total Net P&L'},
                         color='product', template='plotly_white')
        
        line_fig = px.line(df, x='trade_date', y='cumulative_pnl', color='product',
                           title='Cumulative P&L Over Time', markers=True,
                           labels={'trade_date': 'Date', 'cumulative_pnl': 'Cumulative Net P&L'},
                           template='plotly_white')
        
        df['trade_date'] = df['trade_date'].dt.strftime('%Y-%m-%d')
        
        return df.to_dict('records'), bar_fig, line_fig

if __name__ == '__main__':
    server.run(debug=True)