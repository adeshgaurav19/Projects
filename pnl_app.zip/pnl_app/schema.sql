-- Drop tables if they exist to ensure a clean setup
DROP TABLE IF EXISTS trades;
DROP TABLE IF EXISTS market_data;
DROP TABLE IF EXISTS pnl_snapshots;
DROP TABLE IF EXISTS pnl_report;

-- Create the trades table
CREATE TABLE trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trade_date TEXT NOT NULL,
    product TEXT NOT NULL,
    trade_type TEXT NOT NULL,
    buy_sell TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    counterparty TEXT,
    status TEXT NOT NULL,
    physical_premium REAL DEFAULT 0,
    consultancy_fee REAL DEFAULT 0,
    demurrage_cost REAL DEFAULT 0,
    custom_charges REAL DEFAULT 0,
    port_charges REAL DEFAULT 0,
    inspection_charges REAL DEFAULT 0,
    tank_rental_cost REAL DEFAULT 0,
    other_costs REAL DEFAULT 0,
    hedging_pnl REAL DEFAULT 0
);

-- Create the pnl_report table with ALL the necessary columns
CREATE TABLE pnl_report (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trade_id INTEGER NOT NULL,
    physical_pnl REAL,
    paper_pnl REAL,
    total_operating_costs REAL,
    net_pnl REAL,
    FOREIGN KEY (trade_id) REFERENCES trades (id)
);

-- Create other tables
CREATE TABLE market_data (
    price_date TEXT NOT NULL,
    product TEXT NOT NULL,
    price REAL NOT NULL,
    PRIMARY KEY (price_date, product)
);
CREATE TABLE pnl_snapshots (
    snapshot_date TEXT NOT NULL,
    trade_id INTEGER NOT NULL,
    unrealized_pnl REAL NOT NULL,
    PRIMARY KEY (snapshot_date, trade_id),
    FOREIGN KEY (trade_id) REFERENCES trades (id)
);